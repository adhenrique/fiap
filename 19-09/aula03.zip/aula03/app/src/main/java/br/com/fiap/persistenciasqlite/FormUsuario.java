package br.com.fiap.persistenciasqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class FormUsuario extends AppCompatActivity {

    EditText edtNome;
    EditText edtEmail;
    MeuDB meuDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_usuario);

        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        meuDB = new MeuDB(this);
    }

    public void salvar(View view) {

        String nome = edtNome.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();


        if(nome.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, getString(R.string.dados_incorretos), Toast.LENGTH_SHORT).show();
            return;
        }

        Usuario usuario = new Usuario(nome, email);

        meuDB.inserir(usuario);

        Toast.makeText(this, getString(R.string.usuario_salvo), Toast.LENGTH_SHORT).show();
        finish();

    }
}
